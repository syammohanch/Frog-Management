<?php
class frog{

    public $table_name;

    public function __construct()
    {
        $this->table_name = "frogs";
    }

    public function add_frogs($database,$frog_name,$gender,$dob){
        $dob_val = date('Y-m-d',strtotime($dob));
        $frog_name = $database->mysqlrealesc($frog_name);
        $sql = "INSERT INTO frogs(name, gender, dob) VALUES('".$frog_name."','".$gender."','".$dob_val."')";
        echo "<br />SQL is : ".$sql;
        $res = $database->query($sql);
        return true;

    }

    public function list_frogs($database){
        $sql = "SELECT * FROM frogs";
        $res = $database->query($sql);
        return $res;
    }

}
?>