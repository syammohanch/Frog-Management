<?php
session_start();
define('DB_HOST','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','frog_mgr');

function __autoload($classname) {
    $filename = "class.". $classname .".php";
    include_once($filename);
}

?>