<?php
class login{
    public $table_name = 'mgr_users';
    public function __construct()
    {
        $this->table_name = 'mgr_users';
    }
    public function check_login($con,$param1,$param2){
        $esc_param1 = $con->mysqlrealesc($param1);
        $esc_param2 = $con->mysqlrealesc($param2);
        $sql = "SELECT * FROM $this->table_name WHERE username = '".$esc_param1."' AND password = '".$esc_param2."' ";
        $res = $con->query($sql);
        return $res;
    }


}
?>