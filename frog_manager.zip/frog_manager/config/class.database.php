<?php
class Database{

    public $db_host;
    public $db_user;
    public $db_pass;
    public $db_database;
    public $db_con;
    public function __construct()
    {
        $this->db_host = DB_HOST;
        $this->db_user = DB_USERNAME;
        $this->db_pass = DB_PASSWORD;
        $this->db_database = DB_DATABASE;
        $this->db_con = mysqli_connect($this->db_host,$this->db_user,$this->db_pass,$this->db_database);
        if ($this->db_con->connect_error)
        {
            die('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
        }
        return $this->db_con;
    }

    public function mysqlrealesc($var){
        $esc_string = mysqli_real_escape_string($this->db_con,$var);
        return $esc_string;
    }

    public function query($sql){
        $res_rows = array();
        $res = mysqli_query($this->db_con,$sql);
        $res_num_rows = mysqli_num_rows($res);
        if($res_num_rows > 0){
            $i=0;
            while($rows = mysqli_fetch_assoc($res)){
                $res_rows[$i] = $rows;
                $i++;
            }
        }
        return $res_rows;
    }

}
?>