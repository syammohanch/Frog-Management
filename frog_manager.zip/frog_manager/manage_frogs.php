<?php
error_reporting(E_ALL);
include_once('config/config.php');
include_once('header_include.php');
$database = new database();
$frog = new frog();
$list_frog = $frog->list_frogs($database);
$list_frog_num = count($list_frog);
?>
<body class="hold-transition skin-blue sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
    <?php include_once('main_header.php');?>
    <!-- =============================================== -->
    <!-- Left side column. contains the sidebar -->
    <?php include_once('main_sidebar.php');?>
    <!-- =============================================== -->
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Main content -->

        <section class="content">
            <div><strong>Frog Manager </strong>- Manage Frogs</div>
            <p>&nbsp;</p>
            <div class="box-body">
                    <table id="example2" class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>No.</th>
                            <th>Name</th>
                            <th>Gender</th>
                            <th>Date of Birth</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if($list_frog_num > 0){
                            for($cntr=0;$cntr<$list_frog_num;$cntr++){
                                $gender = ($list_frog[$cntr]['gender'] == "M") ? "Male" : "Female";
                                echo "<tr>";
                                echo "<td>".($cntr+1)."</td>";
                                echo "<td>".$list_frog[$cntr]['name']."</td>";
                                echo "<td>".$gender."</td>";
                                echo "<td>".date('d M Y',strtotime($list_frog[$cntr]['dob']))."</td>";
                                echo "</tr>";
                            }
                        }
                        ?>
                        </tbody>
                    </table>
                </div>

        </section>
    </div>
</div>
<!-- ./wrapper -->
<!-- jQuery 2.2.0 -->
<link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
<script src="plugins/jQuery/jQuery-2.2.0.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
    $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });
</script>
</body>
</html>
