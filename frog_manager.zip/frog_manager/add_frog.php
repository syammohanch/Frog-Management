<?php
error_reporting(E_ALL);
include_once('config/config.php');
include_once('header_include.php');
$database = new database();
$success_msg = "";
if(isset($_REQUEST['Submit']) && $_REQUEST['Submit'] == "Add"){
    $frog_name = trim($_REQUEST['frog_name']);
    $gender = trim($_REQUEST['gender']);
    $dob = trim($_REQUEST['dob']);
    $frog = new frog();
    $add_frogs = $frog->add_frogs($database,$frog_name,$gender,$dob);
    if($add_frogs){
        $success_msg = "Data saved successfully";
    }
}
?>
<body class="hold-transition skin-blue sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
    <?php include_once('main_header.php');?>
    <!-- =============================================== -->
    <!-- Left side column. contains the sidebar -->
    <?php include_once('main_sidebar.php');?>
    <!-- =============================================== -->
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Main content -->

        <section class="content">
            <div><strong>Frog Manager </strong>- Add Frogs</div>
            <p>&nbsp;</p>
            <div class="box box-default col-md-12">
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12">
                            <?php
                            if($success_msg !=""){
                                echo "<div style='color:green;'>".$success_msg."</div><p>&nbsp;</p>";
                            }
                            ?>
                        <form name="add_frog" method="POST" action="add_frog.php" onsubmit="return add_forg_validate();">

                            <div class="form-group">
                                <label for="exampleInputName">Name</label>
                                <input class="form-control" type="text" id="frog_name" value="" name="frog_name" placeholder="Enter Name">
                            </div>
                            <div class="form-group">
                                <label>Gender</label>
                                <div class="radio">
                                    <label>
                                        <input type="radio" checked="" value="M" id="gender1" name="gender">
                                        Male
                                    </label>
                                </div>
                                <div class="radio">
                                    <label>
                                        <input type="radio" value="F" id="gender2" name="gender">
                                        Female
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Date of Birth:</label>
                                <div class="input-group date">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <input type="text" id="datepicker" name="dob" class="form-control pull-right">
                                </div>
                                <!-- /.input group -->
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary" type="submit" name="Submit" value="Add">Add</button>
                            </div>
                        </form>
                        </div>
                        <!-- /.col -->
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.box-body -->
            </div>
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
</div>
<!-- ./wrapper -->
<!-- jQuery 2.2.0 -->
<script src="plugins/jQuery/jQuery-2.2.0.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script src="plugins/datepicker/bootstrap-datepicker.js"></script>
<script type="text/javascript">
    //Date picker
    $('#datepicker').datepicker({
        autoclose: true
    });
</script>
<script src="dist/js/validation.js" type="text/javascript"></script>
</body>
</html>
